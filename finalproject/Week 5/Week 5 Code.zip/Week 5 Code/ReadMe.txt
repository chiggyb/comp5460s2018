
--------------------------------------------------------------------
Author Name : Chirag Bhardwaj
Final Project Week 4
--------------------------------------------------------------------

1. 3D_chirag file contains the html which uses WebGL to show the 3D rendering created using only 2D coordinates, i.e only x and y coordinates 
2. WebGL provides us with various functions to draw and stylize various objects. I have tried to use most of these so I can finally make my final project as desired.
3. In order to perform these renderings I have tried to translate the drawing to fully demonstrate the 3D effect. 
4. I am using Three.js as the javascript library of WebGL to perform these animations.
5. This week my work made me learn about various textures and light transformations and Environmental Mappings
