--------------------------------------------------------------------
Author Name : Ambati Nikhila
Web Link : http://www.cs.uml.edu/~nambati/427546s2017/prog-hws/4/
username: nambati
Programming Assignment 4
--------------------------------------------------------------------

1.Folder contains "Computer graphics" html homepage file which portrays planar geometric projections like the following:
Parallel: Multiview Orthographic projection, Axonometric projections (Isometric, Dimetric, Trimetric), Oblique projections.
Perspective: One-point projection, Two-point projection, Three-point projection.

2.Also the homepage shows 3D transformations of Front view, Side view, Top view, & Entire house 3D projection which are extended from Programming Assignment 3.

3.The homepage "Computer Graphics" file contains html, svg and java script codes in order to show all the eight different projection types of the object "cube".

4.The angles of different oblique projections part of the assignment has been shown in the oblique.html file  to see their influence on the object "cube".

5.3Dhouse.html file shows the "Impress Me" part of the assignment which shows the 3D functionality on an entire house which I have extended from the previous programming assignment.

6.svg provides us with various functions to draw lines, rectangles, circles, paths, polygons etc. The required coordinates for drawing these functions have been passed.

7. Javascript function modifies (tranforms) the svg objects using DOM functions.
	-- DOM gets the id of object using document.getElementById() function.
	--DOM manipulates object by using .style.transform attributes.

