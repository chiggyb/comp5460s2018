
--------------------------------------------------------------------
Author Name : Chirag Bhardwaj
Final Project Week 1
--------------------------------------------------------------------

1.index.html file contains the html, svg as well as java script code in order to perfrom two-dimensional transformations on Front/Side/Top elevations.
2.svg provides us with various functions to draw lines, rectangles, circles, paths, polygons etc. The required coordinates for drawing these functions have been passed. 
3. In order to perform translation, rotation, scaling, and shearing, I have used basic transformation functions like :
   translation : translate(x,y)
   rotation : rotate(angle)
   scaling : scale(x,y)
   shearing : skewX(angle)
4.In order to take the input from the user, slider input has been used in the given assignment which provides direct manipulation ability to the user. 
  oncharge="function(this.value)" has been utilized to pass the input values to javascript.
5.Using DOM functions, the javascript function transforms the svg objects.
  DOM gets the "id" of the object using document.getElementById() function.
  DOM manipulates the object by using .style.transform attributes.
6.All the objects in this programming assignment have been made 3D ready for future assignments.
