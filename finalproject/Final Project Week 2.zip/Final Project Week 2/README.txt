
--------------------------------------------------------------------
Author Name : Chirag Bhardwaj
Final Project Week 2
--------------------------------------------------------------------

1.cube.html file contains the html which uses WebGL to show the 3D rendering created. 
2. WebGL provides us with various functions to draw and stylize various objects. The required coordinates for drawing these functions have been passed. 
3. In order to perform these renderings I have tried to rotate the drawing to fully demonstrate the 3D effect. 
4. I am using Three.js as the javascript library of WebGL to perform these animations.
5. This week my work made me learn about 3D renderings, camera use and most importantly WEBGL 
