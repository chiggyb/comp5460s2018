--------------------------------------------------------------------
Author Name : Chirag Bhardwaj
Programming Assignment 1
--------------------------------------------------------------------
Shapes successfully implemented:
1. Circle
2. Line
3. Polyline
4. Polygon
5. Rectangle


Procedure:
1. Go to CG homepage.html
2. Select shape.
3. Click on the draw BUTTON
4. Click on clear to restart

Work Done for the extra credits of the homework:

Implemntation of RUBBERBANDING was also done in this homework.
A Guide on how to use the Rubberbanding implemented has also been given on the rubberbanding.html page itself.

Issues:
1. Sometimes the colors may not show up unless the canvas is cleaned.

REFERENCES:
1. http://stackoverflow.com/
