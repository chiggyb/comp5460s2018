from turtle import penup
from turtle import pendown
from turtle import speed
from turtle import hideturtle
from turtle import left
from turtle import right
from turtle import forward
from turtle import mainloop
import turtle
from random import randint

myTurtle=turtle.Turtle()

def drawFractal(inputPrimitive,lengthSide,ratio,iterations):
    if(inputPrimitive == 'line'):
        fractal(lengthSide,ratio,iterations)
        return
    elif(inputPrimitive == 'arc'):
        fractal2(length,ratio,iterations)
        return

def fractal(lengthSide,ratio, iterations):
    if iterations == 0:
        myTurtle.forward(lengthSide)
        return
    lengthSide /=ratio
    #fractal(lengthSide,ratio, iterations-1)
    myTurtle.left(45)
    if (iterations==3):
        fractal(lengthSide,ratio, iterations-1)
    myTurtle.right(230)
    if (iterations==2 or iterations==3):
        fractal(lengthSide,ratio, iterations-1)
    myTurtle.left(60)
    fractal(lengthSide,ratio, iterations-1)
    return

def fractal2(lengthSide,ratio, iterations):
    lengthSide/=ratio
    if(iterations!=0):
        for x in range (0,ratio):
            myTurtle.setheading(180-randint(0,180))
            myTurtle.circle(lengthSide,180)
        fractal2(lengthSide*ratio,ratio,iterations-1)
    else:
        return

if __name__ == "__main__":

    myTurtle.speed(0)
    myTurtle.hideturtle()
    length = 100.0
    penup()

# Move the turtle backward by distance,
# opposite to the direction the turtle
# is headed.

    pendown()

    drawFractal('line',length,2,3)


# To control the closing windows of the turtle
    mainloop()
